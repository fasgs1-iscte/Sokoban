package pt.iscte.dcti.poo.sokoban.starter;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import java.util.Scanner;

import pt.iul.ista.poo.gui.ImageMatrixGUI;

import pt.iul.ista.poo.observer.Observed;
import pt.iul.ista.poo.observer.Observer;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Point2D;

public class SokobanGame implements Observer {

	private Player player;
	private ArrayList<AbstractSObjects> tiles;
	private int l = 0;
	private ArrayList<Integer> leaderBoard;

	public SokobanGame() {

		tiles = buildSampleLevel();
		leaderBoard = updateLeaderBoard();
		leaderBoard.sort(new ComparadordeNumeros());
		for (AbstractSObjects f : tiles)
			ImageMatrixGUI.getInstance().addImage(f);
	}

	private ArrayList<AbstractSObjects> buildSampleLevel() {

		ArrayList<AbstractSObjects> sampleLevelTiles = new ArrayList<AbstractSObjects>();

		// Build 10x10 floor tiles
		for (int x = 0; x != 10; x++)
			for (int y = 0; y != 10; y++)
				sampleLevelTiles.add(new Chao(new Point2D(x, y), true, 1));

		try {
			Scanner s = new Scanner(new File("levels/level" + l + ".txt"));
			int j = 0;
			while (s.hasNextLine()) {
				String linha = s.nextLine();
				for (int i = 0; i < 10; i++) {
					char caracter = linha.charAt(i);
					String tipo = String.valueOf(caracter);
					System.out.println(tipo);
					switch (tipo) {
					case "#":
						Parede parede = new Parede(new Point2D(i, j), false, 10);
						sampleLevelTiles.add(parede);
						break;
					case "C":
						Caixote caixote = new Caixote(new Point2D(i, j), false, 10);
						sampleLevelTiles.add(caixote);
						break;
					case "E":
						player = new Player(new Point2D(i, j), false, 10);
						sampleLevelTiles.add(player);
						break;
					case "b":
						Bateria b = new Bateria(new Point2D(i, j), true, 10);
						sampleLevelTiles.add(b);
						break;
					case "X":
						Alvo x = new Alvo(new Point2D(i, j), true, 9);
						sampleLevelTiles.add(x);
						break;
					case "O":
						Buraco bu = new Buraco(new Point2D(i, j), true, 10);
						sampleLevelTiles.add(bu);
						break;
					case "p":
						SmallStone st = new SmallStone(new Point2D(i, j), false, 10);
						sampleLevelTiles.add(st);
						break;
					case "P":
						BigStone sto = new BigStone(new Point2D(i, j), false, 10);
						sampleLevelTiles.add(sto);
						break;
					case "t":
						Portal p = new Portal(new Point2D(i, j), true, 10);
						sampleLevelTiles.add(p);
						break;
					case "m":
						Martelo m = new Martelo(new Point2D(i, j), true, 10);
						sampleLevelTiles.add(m);
						break;
					case "%":
						Parede_Partida pp = new Parede_Partida(new Point2D(i, j), false, 10);
						sampleLevelTiles.add(pp);
						break;
					case "g":
						Gelo g = new Gelo(new Point2D(i, j), true, 1);
						sampleLevelTiles.add(g);
						break;
					}
				}
				j++;
			}
			s.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		l++;
		return sampleLevelTiles;
	}

	public int numberOfTargets() {
		int x = 0;
		for (AbstractSObjects obj : tiles) {
			if (obj instanceof Alvo) {
				x = x + 1;
			}
		}
		return x;
	}

	public boolean levelCleared() {
		boolean a = false;
		int x = 0;
		for (AbstractSObjects obj : tiles) {
			if (obj instanceof Alvo) {
				for (AbstractSObjects p : tiles) {
					if (p instanceof Caixote && obj.getPosition().equals(p.getPosition())) {
						x = x + 1;

					}
				}
			}
		}
		if (x == numberOfTargets()) {
			a = true;
		}
		return a;
	}

	public void loadLevel() {

		tiles.clear();
		ImageMatrixGUI.getInstance().clearImages();
		tiles = buildSampleLevel();
		for (AbstractSObjects f : tiles)
			ImageMatrixGUI.getInstance().addImage(f);

	}

	public ArrayList<Integer> updateLeaderBoard() {
		ArrayList<Integer> LeaderBoard = new ArrayList<Integer>();
		try {
			Scanner s = new Scanner(new File("LeaderBoard/LeaderBoard.txt"));
			while (s.hasNextLine()) {
				int n = s.nextInt();
				LeaderBoard.add(n);

			}
			s.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return LeaderBoard;

	}

	public void addScore(int p) {
		leaderBoard.add(p);
	}

	@Override
	public void update(Observed arg0) {

		int lastKeyPressed = ((ImageMatrixGUI) arg0).keyPressed();
		System.out.println("Key pressed " + lastKeyPressed);
		// VK_UP, VK_DOWN, VK_LEFT, VK_RIGHT
		if (Direction.isDirection(lastKeyPressed)) {
			if (player != null) {
				player.movePlayer(tiles, Direction.directionFor(lastKeyPressed));
				ImageMatrixGUI.getInstance().setStatusMessage("Level" + l + "          " + "Moves : "
						+ player.getMoves() + "          Batery : " + player.getBatery() + "%");

				
				if (levelCleared() && l<=2) {
					addScore(player.getMoves());
					leaderBoard.sort(new ComparadordeNumeros());
					player.setMoves(0);
					ImageMatrixGUI.getInstance().setMessage("N�vel " + l + " conclu�do");
					loadLevel();
					

				}
				else {
					if(l == 3 && levelCleared() ) {
					ImageMatrixGUI.getInstance().setMessage("Parab�ns conclu�ste o jogo");
					ImageMatrixGUI.getInstance().dispose();
					}
				}
				
				

				for (int n : leaderBoard)
					System.out.println(n);

			}

		}

		ImageMatrixGUI.getInstance().update();
	}

}
