package pt.iscte.dcti.poo.sokoban.starter;

import pt.iul.ista.poo.utils.Point2D;

public class BigStone extends MovableObject {
	
	public BigStone(Point2D position, boolean p, int layer) {
		super(position,p,layer,"BigStone");
	}

}
