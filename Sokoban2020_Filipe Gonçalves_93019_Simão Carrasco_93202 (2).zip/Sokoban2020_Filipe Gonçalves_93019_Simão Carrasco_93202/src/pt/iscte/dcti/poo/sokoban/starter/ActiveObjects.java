package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.gui.ImageTile;


public interface ActiveObjects extends ImageTile {
	
	public void interaction(MovableObject obj, ArrayList<AbstractSObjects> tiles);
	

}
