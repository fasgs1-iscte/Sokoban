package pt.iscte.dcti.poo.sokoban.starter;

import pt.iul.ista.poo.utils.Point2D;

public class SmallStone extends MovableObject {

	public SmallStone(Point2D position, boolean movement, int layer) {
		super(position, movement, layer, "SmallStone");
		
	}

}
