package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.utils.Point2D;

public class Portal extends AbstractSObjects implements ActiveObjects {

	public Portal(Point2D position, boolean movement, int layer) {
		super(position, movement, layer, "Portal_Azul");

	}

	@Override
	public void interaction(MovableObject obj, ArrayList<AbstractSObjects> tiles) {
		ArrayList<AbstractSObjects> aux = new ArrayList<AbstractSObjects>();
		for (AbstractSObjects obj2 : tiles) {
			aux.add(obj2);
		}
		for (AbstractSObjects p : aux) {
			if (p instanceof Portal && p.getPosition().getX() != getPosition().getX()
					&& p.getPosition().getY() != getPosition().getY()) {
				for (AbstractSObjects p2 : tiles) {
					if (p2 instanceof MovableObject && p2.getPosition().equals(p.getPosition())) {
						setWalkability(false);
					}
					else {
						setWalkability(true);
						obj.setPosition(p.getPosition());
					}
					
				}

			}

		}
	}

}
