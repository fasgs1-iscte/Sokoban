package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Point2D;

public class Gelo extends AbstractSObjects  {

    public Gelo(Point2D position, boolean movement, int layer) {
        super(position, movement, layer, "Gelo");

    }


    public void interaction(MovableObject obj, ArrayList<AbstractSObjects> tiles, Direction d) {
        Point2D newPosition=obj.getPosition().plus(d.asVector());


            if( obj.canMove(tiles,newPosition)==true) {
                obj.moveMovableObject(tiles, d);

            }
        }

        }