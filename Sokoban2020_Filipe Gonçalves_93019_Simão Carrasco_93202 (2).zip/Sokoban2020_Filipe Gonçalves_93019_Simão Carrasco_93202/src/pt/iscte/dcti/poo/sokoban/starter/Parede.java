package pt.iscte.dcti.poo.sokoban.starter;


import pt.iul.ista.poo.utils.Point2D;

public class Parede extends AbstractSObjects {
	
	
	public Parede(Point2D position, boolean movement, int layer) {
		super(position,movement, layer, "Parede");
		
		
		
	}
	
	
	
	

	
	
	

}

