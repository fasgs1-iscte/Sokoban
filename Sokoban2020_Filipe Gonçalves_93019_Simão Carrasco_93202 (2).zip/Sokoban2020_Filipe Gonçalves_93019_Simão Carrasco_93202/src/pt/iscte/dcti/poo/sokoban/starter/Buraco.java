package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Point2D;

public class Buraco extends AbstractSObjects implements ActiveObjects {
	
	

	public Buraco(Point2D position, boolean p, int layer) {
		super(position,p, layer, "Buraco");
		
	}

	
	@Override
	public void interaction(MovableObject obj, ArrayList<AbstractSObjects> tiles) {
		
			
				if(obj instanceof BigStone) { 
					obj.setPosition(getPosition());
					obj.setLayer(getLayer()+1);
					setWalkability(false);
				}
				else {
					if(obj instanceof Player ) {
						ImageMatrixGUI.getInstance().dispose();
					}
					else {
						tiles.remove(obj);
						setWalkability(false);
					}
					
					
				
				}
			 
					
				}
	}
				
				
				
			
		
		
