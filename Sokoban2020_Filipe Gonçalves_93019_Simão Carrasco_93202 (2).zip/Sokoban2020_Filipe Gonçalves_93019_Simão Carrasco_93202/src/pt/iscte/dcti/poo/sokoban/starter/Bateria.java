package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Point2D;

public class Bateria extends AbstractSObjects implements ActiveObjects {
	
	
	
	public Bateria(Point2D position, boolean p,int layer) {
		super(position, p, layer ,"Bateria");
		
	}

	@Override
	public void interaction(MovableObject obj, ArrayList<AbstractSObjects> tiles) {
		
			if(obj instanceof Player) {
				((Player) obj).setBatery(100);
				tiles.remove(this);
				ImageMatrixGUI.getInstance().removeImage(this);
			}
		}
		
	}

