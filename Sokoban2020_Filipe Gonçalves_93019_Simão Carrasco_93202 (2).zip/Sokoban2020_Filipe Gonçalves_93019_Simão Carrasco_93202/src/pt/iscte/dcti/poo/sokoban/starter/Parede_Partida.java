package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Point2D;

public class Parede_Partida extends AbstractSObjects  {

	public Parede_Partida(Point2D position, boolean movement, int layer) {
		super(position, movement, layer, "Parede_Partida");
		
	}

	
	public void interaction(MovableObject obj, ArrayList<AbstractSObjects> tiles) {
		if(obj instanceof Player && ((Player)obj).isHasMartelo()==true) {
			tiles.remove(this);
			ImageMatrixGUI.getInstance().removeImage(this);
		}
		
	}

}
