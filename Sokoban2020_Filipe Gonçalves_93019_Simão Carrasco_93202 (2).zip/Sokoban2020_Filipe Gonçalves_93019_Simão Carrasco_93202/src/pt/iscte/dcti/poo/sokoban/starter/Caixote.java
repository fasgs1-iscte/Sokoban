package pt.iscte.dcti.poo.sokoban.starter;



import pt.iul.ista.poo.utils.Point2D;

public class Caixote extends MovableObject {
	
	
	
	public Caixote(Point2D position, boolean p, int layer) {
		super(position,p,layer,"Caixote");
		
		
	

	
		
	
	
	
	
	
	
}
}

