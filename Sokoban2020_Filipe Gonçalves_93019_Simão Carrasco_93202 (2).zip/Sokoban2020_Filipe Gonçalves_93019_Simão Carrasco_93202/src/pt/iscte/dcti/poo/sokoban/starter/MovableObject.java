package pt.iscte.dcti.poo.sokoban.starter;

import java.util.ArrayList;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Point2D;

public class MovableObject extends AbstractSObjects implements ImageTile {

    public MovableObject(Point2D position, boolean movement, int layer, String name) {
        super(position, movement, layer, name);

    }

    public boolean canMove(ArrayList<AbstractSObjects> tiles, Point2D position) {

        for (AbstractSObjects obj : tiles) {
            if (obj.getPosition().equals(position) && obj.isWalkable() == false) {

                return false;

            }

        }
        return true;

    }

    public void moveMovableObject(ArrayList<AbstractSObjects> tiles, Direction d) {
        Point2D newPosition = getPosition().plus(d.asVector());
        ArrayList<AbstractSObjects> aux = new ArrayList<AbstractSObjects>();
  
        for(AbstractSObjects obj  : tiles) {
         	aux.add(obj);
         	}
        
        if (canMove(tiles, newPosition) == true && newPosition.getX() >= 0 && newPosition.getX() < 10
                && newPosition.getY() >= 0 && newPosition.getY() < 10) {
            setPosition(newPosition);
            for(AbstractSObjects obj  : aux) {
             	if( obj instanceof ActiveObjects && obj.getPosition().equals(newPosition)) {
             		((ActiveObjects) obj).interaction(this, tiles);
             		
             	}
             	if(obj.getPosition().equals(newPosition) && obj instanceof Gelo) {
             		((Gelo)obj).interaction(this, tiles, d);
             	}
             	
             }
           
            
           

        }
        
        ImageMatrixGUI.getInstance().update();

    }
}
