package pt.iscte.dcti.poo.sokoban.starter;




import pt.iul.ista.poo.gui.ImageTile;

import pt.iul.ista.poo.utils.Point2D;

public abstract class AbstractSObjects implements ImageTile {
	private boolean walkable;
	private Point2D position;
	private int layer;
	private String name;

	public AbstractSObjects(Point2D position, boolean movement, int layer, String name) {
		this.name=name;
		this.position = position;
		this.walkable = movement;
		this.layer=layer;
	}
	public String getName(){
		return name;
	}
	

	public void setName(String name) {
		this.name = name;
	}
	public Point2D getPosition() {
		return position;
	}

	public void setPosition(Point2D position) {
		this.position = position;
	}

	public boolean isWalkable() {
		return walkable;
	}
	public void setWalkability(boolean a) {
		walkable =a;
	
	}

	public int getLayer() {

		return layer;
	}
	public void setLayer(int n) {
		layer = n;
	}
}
