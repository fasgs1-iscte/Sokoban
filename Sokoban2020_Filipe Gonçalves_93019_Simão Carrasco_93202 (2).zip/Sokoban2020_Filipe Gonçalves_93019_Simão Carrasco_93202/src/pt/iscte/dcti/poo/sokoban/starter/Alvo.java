package pt.iscte.dcti.poo.sokoban.starter;



import pt.iul.ista.poo.utils.Point2D;

public class Alvo extends AbstractSObjects {
	
	

	public Alvo(Point2D position, boolean p, int layer) {
		super(position,p, layer, "Alvo");
		
	}
	
	
	


	}
