package pt.iscte.dcti.poo.sokoban.starter;


import java.util.ArrayList;


import pt.iul.ista.poo.gui.ImageMatrixGUI;

import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Point2D;

public class Player extends MovableObject {

	private int batery = 100;
	private boolean hasMartelo = false;
	private int moves = 0;

	public Player(Point2D position, boolean movement, int layer) {
		super(position, movement, layer, "Empilhadora_D");

	}

	public int getBatery() {
		return batery;
	}

	public void setBatery(int batery) {
		this.batery = batery;
	}

	public void setMartelo(boolean a) {
		this.hasMartelo = a;
	}

	public boolean isHasMartelo() {
		return hasMartelo;
	}

	public int getMoves() {
		return moves;
	}

	public void setMoves(int moves) {
		this.moves = moves;
	}

	public void changeImage(Direction d) {
		if (d == Direction.DOWN) {
			setName("Empilhadora_D");

		}
		if (d == Direction.UP) {
			setName("Empilhadora_U");

		}
		if (d == Direction.LEFT) {
			setName("Empilhadora_L");

		}
		if (d == Direction.RIGHT) {
			setName("Empilhadora_R");

		}

	}

	public void movePlayer(ArrayList<AbstractSObjects> tiles, Direction d) {
		changeImage(d);
		Point2D newPosition = getPosition().plus(d.asVector());
		ArrayList<AbstractSObjects> aux = new ArrayList<AbstractSObjects>();
		for (AbstractSObjects obj : tiles) {
			aux.add(obj);
		}

		if (batery > 0) {
			if (canMove(tiles, newPosition) == true) {
				setPosition(newPosition);
				batery = batery - 1;
				moves++;
				for (AbstractSObjects obj : aux) {
					if (obj instanceof ActiveObjects && obj.getPosition().equals(newPosition)) {
						((ActiveObjects) obj).interaction(this, tiles);

					}
					if (obj.getPosition().equals(newPosition) && obj instanceof Gelo) {
						((Gelo) obj).interaction(this, tiles, d);
					}
				}

			} else {
				for (AbstractSObjects obj : aux) {

					if (obj.getPosition().equals(newPosition) && obj instanceof MovableObject
							&& obj.getLayer() == getLayer()) {
						Point2D newPosition2 = obj.getPosition().plus(d.asVector());
						if (((MovableObject) obj).canMove(tiles, newPosition2)) {
							((MovableObject) obj).moveMovableObject(tiles, d);
							setPosition(newPosition);
							batery = batery - 1;
							moves++;
						}

					}

					if (obj instanceof Parede_Partida && obj.getPosition().equals(newPosition)) {
						((Parede_Partida) obj).interaction(this, tiles);

					}

				}
				for(AbstractSObjects obj  : aux) {
	             	if( obj instanceof Buraco ) {
	             		obj.setWalkability(true);
	             		
	             	}

			}

		}
		ImageMatrixGUI.getInstance().update();

	}

}
	}
