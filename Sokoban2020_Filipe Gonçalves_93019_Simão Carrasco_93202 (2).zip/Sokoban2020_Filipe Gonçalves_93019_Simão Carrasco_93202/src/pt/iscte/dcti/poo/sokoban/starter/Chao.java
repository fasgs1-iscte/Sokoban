package pt.iscte.dcti.poo.sokoban.starter;

import pt.iul.ista.poo.utils.Point2D;

public class Chao extends AbstractSObjects {

	public Chao(Point2D Point2D, boolean movement, int layer){
		super(Point2D,movement, layer, "Chao");
		
		
	
	

}
}
